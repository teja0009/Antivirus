﻿Imports System.IO
Imports System.Runtime.InteropServices

Public Class MyFunctions

    Public Shared username As String
    Public Shared password As String
    Public Shared host As String
    Public Shared location As String



    Public Const WM_NCLBUTTONDOWN As Integer = &HA1
    Public Const HT_CAPTION As Integer = &H2


    <DllImportAttribute("user32.dll")>
    Public Shared Function SendMessage(ByVal hWnd As IntPtr, ByVal Msg As Integer, ByVal wParam As Integer, ByVal lParam As Integer) As Integer
    End Function

    <DllImportAttribute("user32.dll")>
    Public Shared Function ReleaseCapture() As Boolean
    End Function

    Public Shared Sub privacyClick()
        With Form1.btnDashboaard
            .BottomColor = MyColors.deactive_color1
            .TopColor = MyColors.deactive_color2
        End With
        Form1.imgDashbaord.BackColor = MyColors.imageDeactiveColor

        With Form1.btnProtection
            .BottomColor = MyColors.deactive_color1
            .TopColor = MyColors.deactive_color2

        End With
        Form1.imgProtection.BackColor = MyColors.imageDeactiveColor

        With Form1.btnPrivacy

            .BottomColor = MyColors.active_color1
            .TopColor = MyColors.active_color2

        End With
        Form1.imgPrivacy.BackColor = MyColors.imageActiveColor

        With Form1.btnNotification
            .BottomColor = MyColors.deactive_color1
            .TopColor = MyColors.deactive_color2
        End With
        Form1.imgNotification.BackColor = MyColors.imageDeactiveColor

        With Form1.btnAccount
            .BottomColor = MyColors.deactive_color1
            .TopColor = MyColors.deactive_color2
        End With
        Form1.imgAccount.BackColor = MyColors.imageDeactiveColor


        Form1.imgPref.BackColor = MyColors.imageDeactiveColor


        Form1.imgHelp.BackColor = MyColors.imageDeactiveColor
    End Sub

    Public Shared Sub systemPerformance()

        With Form1.btnDashboaard
            .BottomColor = MyColors.deactive_color1
            .TopColor = MyColors.deactive_color2
        End With
        Form1.imgDashbaord.BackColor = MyColors.imageDeactiveColor

        With Form1.btnProtection
            .BottomColor = MyColors.deactive_color1
            .TopColor = MyColors.deactive_color2

        End With
        Form1.imgProtection.BackColor = MyColors.imageDeactiveColor

        With Form1.btnPrivacy
            .BottomColor = MyColors.deactive_color1
            .TopColor = MyColors.deactive_color2
        End With
        Form1.imgPrivacy.BackColor = MyColors.imageDeactiveColor

        With Form1.btnNotification
            .BottomColor = MyColors.active_color1
            .TopColor = MyColors.active_color2
        End With
        Form1.imgNotification.BackColor = MyColors.imageActiveColor

        With Form1.btnAccount
            .BottomColor = MyColors.deactive_color1
            .TopColor = MyColors.deactive_color2
        End With
        Form1.imgAccount.BackColor = MyColors.imageDeactiveColor


        Form1.imgPref.BackColor = MyColors.imageDeactiveColor


        Form1.imgHelp.BackColor = MyColors.imageDeactiveColor
    End Sub


    Public Shared Sub Enable_Firewall()
        Dim firewall As New Process
        firewall.StartInfo.FileName = "cmd.exe"
        firewall.StartInfo.WorkingDirectory = "\windows\system32\"
        firewall.StartInfo.Arguments = "/c netsh fireball set opmode mode=enable"
        firewall.Start()
        MsgBox("Firewall Enabled Sucessfully!", MsgBoxStyle.Information, "Attention!")
        My.Settings.firewall = True
        My.Settings.Save()
    End Sub

    Public Shared Sub Disable_Firewall()
        Dim firewall As New Process
        firewall.StartInfo.FileName = "cmd.exe"
        firewall.StartInfo.WorkingDirectory = "\windows\system32\"
        firewall.StartInfo.Arguments = "/c netsh fireball set opmode mode=disable"
        firewall.Start()
        MsgBox("Firewall Disabled Sucessfully!", MsgBoxStyle.Information, "Attention!")
        My.Settings.firewall = False
        My.Settings.Save()
    End Sub


    Public Shared Sub Scan()
        frmScan.ShowDialog()
        frmScan.FolderBrowserDialog1.SelectedPath = "C:\"

        On Error Resume Next

        For Each strDir As String In System.IO.Directory.GetDirectories(frmScan.FolderBrowserDialog1.SelectedPath, "*.*", IO.SearchOption.TopDirectoryOnly)
            For Each strFile As String In System.IO.Directory.GetFiles(strDir, "*.*", SearchOption.AllDirectories)
                frmScan.ListBox1.Items.Add(strFile)
            Next
        Next

        frmScan.MyButton1.Enabled = False
        frmScan.MyButton3.Enabled = True
        frmScan.MyButton4.Enabled = True
        frmScan.Timer1.Start()
        frmScan.ProgressBar1.Visible = False
    End Sub

    Public Shared Sub startVPN()
        username = "freevpn"
        host = "83.170.115.92"
        password = "account"
        location = "USA"
        Form1.CtlPrivacy1.PictureBox3.Image = Form1.CtlPrivacy1.PictureBox1.Image

        With Form1

            .CtlPrivacy1.MyButton1.PerformClick()

        End With
    End Sub

    Public Shared Sub userDetails()
        If My.Settings.ActivationStatus = True Then
            With Form1
                .CtlAccount1.MyButton1.Visible = False
                .CtlAccount1.MyButton2.Visible = False
            End With
        End If
        With Form1

            .CtlAccount1.lblEmail.Text = My.Settings.email
            .CtlAccount1.lblExpiry.Text = My.Settings.expiry
            .CtlAccount1.lblKey.Text = My.Settings.serialKey
            .CtlAccount1.lblValidation.Text = My.Settings.validation
        End With

    End Sub

End Class
