﻿Public Class ctlPremium
    Private Sub ctlPremium_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub MyButton1_Click(sender As Object, e As EventArgs) Handles MyButton1.Click
        Form1.CtlSubscription1.BringToFront()
        Form1.CtlSubscription1.Visible = True
    End Sub
End Class
