﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.SidePanel = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.imgNotification = New System.Windows.Forms.PictureBox()
        Me.imgPrivacy = New System.Windows.Forms.PictureBox()
        Me.imgDashbaord = New System.Windows.Forms.PictureBox()
        Me.imgProtection = New System.Windows.Forms.PictureBox()
        Me.imgAccount = New System.Windows.Forms.PictureBox()
        Me.btnDashboaard = New PC_Protector.MyButton()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.btnNotification = New PC_Protector.MyButton()
        Me.btnPrivacy = New PC_Protector.MyButton()
        Me.btnProtection = New PC_Protector.MyButton()
        Me.btnAccount = New PC_Protector.MyButton()
        Me.HeaderPanel = New System.Windows.Forms.Panel()
        Me.MyButton8 = New PC_Protector.MyButton()
        Me.imgHelp = New System.Windows.Forms.PictureBox()
        Me.btnMinimize = New System.Windows.Forms.PictureBox()
        Me.btnClose = New System.Windows.Forms.PictureBox()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.imgPref = New System.Windows.Forms.PictureBox()
        Me.MainPanel = New System.Windows.Forms.Panel()
        Me.CtlDashboard1 = New PC_Protector.ctlDashboard()
        Me.CtlScanCenter1 = New PC_Protector.ctlScanCenter()
        Me.CtlPrivacy1 = New PC_Protector.ctlPrivacy()
        Me.CtlSystemPerformance1 = New PC_Protector.ctlSystemPerformance()
        Me.CtlAccount1 = New PC_Protector.ctlAccount()
        Me.CtlPremium1 = New PC_Protector.ctlPremium()
        Me.CtlSubscription1 = New PC_Protector.ctlSubscription()
        Me.SidePanel.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.imgNotification, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgPrivacy, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgDashbaord, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgProtection, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgAccount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.HeaderPanel.SuspendLayout()
        CType(Me.imgHelp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnMinimize, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnClose, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgPref, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MainPanel.SuspendLayout()
        Me.SuspendLayout()
        '
        'SidePanel
        '
        Me.SidePanel.BackColor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.SidePanel.Controls.Add(Me.Panel1)
        Me.SidePanel.Controls.Add(Me.btnDashboaard)
        Me.SidePanel.Controls.Add(Me.PictureBox8)
        Me.SidePanel.Controls.Add(Me.btnNotification)
        Me.SidePanel.Controls.Add(Me.btnPrivacy)
        Me.SidePanel.Controls.Add(Me.btnProtection)
        Me.SidePanel.Controls.Add(Me.btnAccount)
        Me.SidePanel.Dock = System.Windows.Forms.DockStyle.Left
        Me.SidePanel.Location = New System.Drawing.Point(0, 0)
        Me.SidePanel.Name = "SidePanel"
        Me.SidePanel.Size = New System.Drawing.Size(219, 647)
        Me.SidePanel.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(18, Byte), Integer), CType(CType(23, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.Panel1.Controls.Add(Me.imgNotification)
        Me.Panel1.Controls.Add(Me.imgPrivacy)
        Me.Panel1.Controls.Add(Me.imgDashbaord)
        Me.Panel1.Controls.Add(Me.imgProtection)
        Me.Panel1.Controls.Add(Me.imgAccount)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(53, 647)
        Me.Panel1.TabIndex = 9
        '
        'imgNotification
        '
        Me.imgNotification.Image = Global.PC_Protector.My.Resources.Resources.icons8_realtime_480px
        Me.imgNotification.Location = New System.Drawing.Point(3, 277)
        Me.imgNotification.Name = "imgNotification"
        Me.imgNotification.Size = New System.Drawing.Size(50, 35)
        Me.imgNotification.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgNotification.TabIndex = 14
        Me.imgNotification.TabStop = False
        '
        'imgPrivacy
        '
        Me.imgPrivacy.Image = Global.PC_Protector.My.Resources.Resources.icons8_privacy_500px
        Me.imgPrivacy.Location = New System.Drawing.Point(3, 235)
        Me.imgPrivacy.Name = "imgPrivacy"
        Me.imgPrivacy.Size = New System.Drawing.Size(50, 37)
        Me.imgPrivacy.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgPrivacy.TabIndex = 12
        Me.imgPrivacy.TabStop = False
        '
        'imgDashbaord
        '
        Me.imgDashbaord.BackColor = System.Drawing.Color.Blue
        Me.imgDashbaord.Image = Global.PC_Protector.My.Resources.Resources.icons8_dashboard_512px
        Me.imgDashbaord.Location = New System.Drawing.Point(-1, 155)
        Me.imgDashbaord.Name = "imgDashbaord"
        Me.imgDashbaord.Size = New System.Drawing.Size(54, 37)
        Me.imgDashbaord.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgDashbaord.TabIndex = 0
        Me.imgDashbaord.TabStop = False
        '
        'imgProtection
        '
        Me.imgProtection.Image = Global.PC_Protector.My.Resources.Resources.icons8_hips_500px
        Me.imgProtection.Location = New System.Drawing.Point(3, 195)
        Me.imgProtection.Name = "imgProtection"
        Me.imgProtection.Size = New System.Drawing.Size(50, 37)
        Me.imgProtection.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgProtection.TabIndex = 10
        Me.imgProtection.TabStop = False
        '
        'imgAccount
        '
        Me.imgAccount.Image = Global.PC_Protector.My.Resources.Resources.icons8_female_profile_500px
        Me.imgAccount.Location = New System.Drawing.Point(0, 610)
        Me.imgAccount.Name = "imgAccount"
        Me.imgAccount.Size = New System.Drawing.Size(53, 37)
        Me.imgAccount.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgAccount.TabIndex = 16
        Me.imgAccount.TabStop = False
        '
        'btnDashboaard
        '
        Me.btnDashboaard.BottomColor = System.Drawing.Color.Blue
        Me.btnDashboaard.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDashboaard.ForeColor = System.Drawing.Color.White
        Me.btnDashboaard.Location = New System.Drawing.Point(49, 155)
        Me.btnDashboaard.Name = "btnDashboaard"
        Me.btnDashboaard.Size = New System.Drawing.Size(176, 37)
        Me.btnDashboaard.TabIndex = 8
        Me.btnDashboaard.Text = "Dashboard"
        Me.btnDashboaard.TopColor = System.Drawing.Color.Gray
        Me.btnDashboaard.UseVisualStyleBackColor = True
        '
        'PictureBox8
        '
        Me.PictureBox8.Image = Global.PC_Protector.My.Resources.Resources.icons8_realtime_480px
        Me.PictureBox8.Location = New System.Drawing.Point(71, 23)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(120, 112)
        Me.PictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox8.TabIndex = 7
        Me.PictureBox8.TabStop = False
        '
        'btnNotification
        '
        Me.btnNotification.BottomColor = System.Drawing.Color.FromArgb(CType(CType(18, Byte), Integer), CType(CType(23, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.btnNotification.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNotification.ForeColor = System.Drawing.Color.White
        Me.btnNotification.Location = New System.Drawing.Point(50, 276)
        Me.btnNotification.Name = "btnNotification"
        Me.btnNotification.Size = New System.Drawing.Size(176, 37)
        Me.btnNotification.TabIndex = 15
        Me.btnNotification.Text = "System Performance"
        Me.btnNotification.TopColor = System.Drawing.Color.Gray
        Me.btnNotification.UseVisualStyleBackColor = True
        '
        'btnPrivacy
        '
        Me.btnPrivacy.BottomColor = System.Drawing.Color.FromArgb(CType(CType(18, Byte), Integer), CType(CType(23, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.btnPrivacy.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPrivacy.ForeColor = System.Drawing.Color.White
        Me.btnPrivacy.Location = New System.Drawing.Point(50, 235)
        Me.btnPrivacy.Name = "btnPrivacy"
        Me.btnPrivacy.Size = New System.Drawing.Size(176, 37)
        Me.btnPrivacy.TabIndex = 13
        Me.btnPrivacy.Text = "Privacy"
        Me.btnPrivacy.TopColor = System.Drawing.Color.Gray
        Me.btnPrivacy.UseVisualStyleBackColor = True
        '
        'btnProtection
        '
        Me.btnProtection.BottomColor = System.Drawing.Color.FromArgb(CType(CType(18, Byte), Integer), CType(CType(23, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.btnProtection.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnProtection.ForeColor = System.Drawing.Color.White
        Me.btnProtection.Location = New System.Drawing.Point(50, 195)
        Me.btnProtection.Name = "btnProtection"
        Me.btnProtection.Size = New System.Drawing.Size(176, 37)
        Me.btnProtection.TabIndex = 11
        Me.btnProtection.Text = "Scan Center"
        Me.btnProtection.TopColor = System.Drawing.Color.Gray
        Me.btnProtection.UseVisualStyleBackColor = True
        '
        'btnAccount
        '
        Me.btnAccount.BottomColor = System.Drawing.Color.FromArgb(CType(CType(18, Byte), Integer), CType(CType(23, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.btnAccount.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAccount.ForeColor = System.Drawing.Color.White
        Me.btnAccount.Location = New System.Drawing.Point(49, 610)
        Me.btnAccount.Name = "btnAccount"
        Me.btnAccount.Size = New System.Drawing.Size(176, 37)
        Me.btnAccount.TabIndex = 18
        Me.btnAccount.Text = "My Acount"
        Me.btnAccount.TopColor = System.Drawing.Color.Gray
        Me.btnAccount.UseVisualStyleBackColor = True
        '
        'HeaderPanel
        '
        Me.HeaderPanel.Controls.Add(Me.MyButton8)
        Me.HeaderPanel.Controls.Add(Me.imgHelp)
        Me.HeaderPanel.Controls.Add(Me.btnMinimize)
        Me.HeaderPanel.Controls.Add(Me.btnClose)
        Me.HeaderPanel.Controls.Add(Me.lblTitle)
        Me.HeaderPanel.Controls.Add(Me.imgPref)
        Me.HeaderPanel.Dock = System.Windows.Forms.DockStyle.Top
        Me.HeaderPanel.Location = New System.Drawing.Point(219, 0)
        Me.HeaderPanel.Name = "HeaderPanel"
        Me.HeaderPanel.Size = New System.Drawing.Size(856, 40)
        Me.HeaderPanel.TabIndex = 1
        '
        'MyButton8
        '
        Me.MyButton8.BottomColor = System.Drawing.Color.Orange
        Me.MyButton8.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MyButton8.ForeColor = System.Drawing.Color.FromArgb(CType(CType(18, Byte), Integer), CType(CType(23, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.MyButton8.Location = New System.Drawing.Point(606, 5)
        Me.MyButton8.Name = "MyButton8"
        Me.MyButton8.Size = New System.Drawing.Size(116, 30)
        Me.MyButton8.TabIndex = 9
        Me.MyButton8.Text = "Go Premium"
        Me.MyButton8.TopColor = System.Drawing.Color.LightGreen
        Me.MyButton8.UseVisualStyleBackColor = True
        '
        'imgHelp
        '
        Me.imgHelp.Image = Global.PC_Protector.My.Resources.Resources.icons8_help_480px
        Me.imgHelp.Location = New System.Drawing.Point(762, 7)
        Me.imgHelp.Name = "imgHelp"
        Me.imgHelp.Size = New System.Drawing.Size(26, 27)
        Me.imgHelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgHelp.TabIndex = 18
        Me.imgHelp.TabStop = False
        '
        'btnMinimize
        '
        Me.btnMinimize.Image = Global.PC_Protector.My.Resources.Resources.icons8_subtract_500px
        Me.btnMinimize.Location = New System.Drawing.Point(795, 7)
        Me.btnMinimize.Name = "btnMinimize"
        Me.btnMinimize.Size = New System.Drawing.Size(23, 24)
        Me.btnMinimize.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.btnMinimize.TabIndex = 4
        Me.btnMinimize.TabStop = False
        '
        'btnClose
        '
        Me.btnClose.Image = Global.PC_Protector.My.Resources.Resources.icons8_delete_500px
        Me.btnClose.Location = New System.Drawing.Point(824, 9)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(19, 20)
        Me.btnClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.btnClose.TabIndex = 3
        Me.btnClose.TabStop = False
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.White
        Me.lblTitle.Location = New System.Drawing.Point(16, 9)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(203, 20)
        Me.lblTitle.TabIndex = 2
        Me.lblTitle.Text = "Star Antivirus - Trial Version"
        '
        'imgPref
        '
        Me.imgPref.Image = Global.PC_Protector.My.Resources.Resources.icons8_settings_208px
        Me.imgPref.Location = New System.Drawing.Point(728, 7)
        Me.imgPref.Name = "imgPref"
        Me.imgPref.Size = New System.Drawing.Size(28, 27)
        Me.imgPref.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgPref.TabIndex = 17
        Me.imgPref.TabStop = False
        '
        'MainPanel
        '
        Me.MainPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.MainPanel.Controls.Add(Me.CtlDashboard1)
        Me.MainPanel.Controls.Add(Me.HeaderPanel)
        Me.MainPanel.Controls.Add(Me.SidePanel)
        Me.MainPanel.Controls.Add(Me.CtlScanCenter1)
        Me.MainPanel.Controls.Add(Me.CtlPrivacy1)
        Me.MainPanel.Controls.Add(Me.CtlSystemPerformance1)
        Me.MainPanel.Controls.Add(Me.CtlAccount1)
        Me.MainPanel.Controls.Add(Me.CtlPremium1)
        Me.MainPanel.Controls.Add(Me.CtlSubscription1)
        Me.MainPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MainPanel.Location = New System.Drawing.Point(0, 0)
        Me.MainPanel.Name = "MainPanel"
        Me.MainPanel.Size = New System.Drawing.Size(1077, 649)
        Me.MainPanel.TabIndex = 2
        '
        'CtlDashboard1
        '
        Me.CtlDashboard1.BackColor = System.Drawing.Color.FromArgb(CType(CType(18, Byte), Integer), CType(CType(23, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.CtlDashboard1.Location = New System.Drawing.Point(220, 41)
        Me.CtlDashboard1.Name = "CtlDashboard1"
        Me.CtlDashboard1.Size = New System.Drawing.Size(852, 606)
        Me.CtlDashboard1.TabIndex = 2
        '
        'CtlScanCenter1
        '
        Me.CtlScanCenter1.BackColor = System.Drawing.Color.FromArgb(CType(CType(18, Byte), Integer), CType(CType(23, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.CtlScanCenter1.Location = New System.Drawing.Point(220, 41)
        Me.CtlScanCenter1.Name = "CtlScanCenter1"
        Me.CtlScanCenter1.Size = New System.Drawing.Size(852, 610)
        Me.CtlScanCenter1.TabIndex = 3
        '
        'CtlPrivacy1
        '
        Me.CtlPrivacy1.BackColor = System.Drawing.Color.FromArgb(CType(CType(18, Byte), Integer), CType(CType(23, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.CtlPrivacy1.Location = New System.Drawing.Point(220, 41)
        Me.CtlPrivacy1.Name = "CtlPrivacy1"
        Me.CtlPrivacy1.Size = New System.Drawing.Size(856, 610)
        Me.CtlPrivacy1.TabIndex = 4
        '
        'CtlSystemPerformance1
        '
        Me.CtlSystemPerformance1.BackColor = System.Drawing.Color.FromArgb(CType(CType(18, Byte), Integer), CType(CType(23, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.CtlSystemPerformance1.Location = New System.Drawing.Point(220, 41)
        Me.CtlSystemPerformance1.Name = "CtlSystemPerformance1"
        Me.CtlSystemPerformance1.Size = New System.Drawing.Size(852, 610)
        Me.CtlSystemPerformance1.TabIndex = 5
        '
        'CtlAccount1
        '
        Me.CtlAccount1.BackColor = System.Drawing.Color.FromArgb(CType(CType(18, Byte), Integer), CType(CType(23, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.CtlAccount1.Location = New System.Drawing.Point(220, 41)
        Me.CtlAccount1.Name = "CtlAccount1"
        Me.CtlAccount1.Size = New System.Drawing.Size(856, 607)
        Me.CtlAccount1.TabIndex = 6
        '
        'CtlPremium1
        '
        Me.CtlPremium1.BackColor = System.Drawing.Color.FromArgb(CType(CType(18, Byte), Integer), CType(CType(23, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.CtlPremium1.Location = New System.Drawing.Point(220, 40)
        Me.CtlPremium1.Name = "CtlPremium1"
        Me.CtlPremium1.Size = New System.Drawing.Size(856, 610)
        Me.CtlPremium1.TabIndex = 7
        '
        'CtlSubscription1
        '
        Me.CtlSubscription1.BackColor = System.Drawing.Color.FromArgb(CType(CType(18, Byte), Integer), CType(CType(23, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.CtlSubscription1.Location = New System.Drawing.Point(-4, 0)
        Me.CtlSubscription1.Name = "CtlSubscription1"
        Me.CtlSubscription1.Size = New System.Drawing.Size(1077, 649)
        Me.CtlSubscription1.TabIndex = 8
        Me.CtlSubscription1.Visible = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(18, Byte), Integer), CType(CType(23, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1077, 649)
        Me.Controls.Add(Me.MainPanel)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "PC Protector"
        Me.SidePanel.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        CType(Me.imgNotification, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgPrivacy, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgDashbaord, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgProtection, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgAccount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        Me.HeaderPanel.ResumeLayout(False)
        Me.HeaderPanel.PerformLayout()
        CType(Me.imgHelp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnMinimize, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnClose, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgPref, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MainPanel.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents SidePanel As Panel
    Friend WithEvents HeaderPanel As Panel
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents imgDashbaord As PictureBox
    Friend WithEvents lblTitle As Label
    Friend WithEvents btnMinimize As PictureBox
    Friend WithEvents btnClose As PictureBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents btnDashboaard As MyButton
    Friend WithEvents MainPanel As Panel
    Friend WithEvents btnAccount As MyButton
    Friend WithEvents imgNotification As PictureBox
    Friend WithEvents imgPrivacy As PictureBox
    Friend WithEvents imgProtection As PictureBox
    Friend WithEvents imgHelp As PictureBox
    Friend WithEvents imgPref As PictureBox
    Friend WithEvents imgAccount As PictureBox
    Friend WithEvents btnNotification As MyButton
    Friend WithEvents btnPrivacy As MyButton
    Friend WithEvents btnProtection As MyButton
    Friend WithEvents MyButton8 As MyButton
    Friend WithEvents CtlDashboard1 As ctlDashboard
    Friend WithEvents CtlScanCenter1 As ctlScanCenter
    Friend WithEvents CtlPrivacy1 As ctlPrivacy
    Friend WithEvents CtlSystemPerformance1 As ctlSystemPerformance
    Friend WithEvents CtlAccount1 As ctlAccount
    Friend WithEvents CtlPremium1 As ctlPremium
    Friend WithEvents CtlSubscription1 As ctlSubscription
End Class
